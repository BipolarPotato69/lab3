import random

class Item:

    def __init__(self, name, price) -> None:
        self.name = name
        self.price = price
    
    def __str__(self) -> str:
        string = "Name: " + self.name + ", price: " + str(self.price) + "."
        return string

class Location:

    def __init__(self, city, postoffice) -> None:
        self.city = city
        self.postoffice = postoffice

class Vehicle:

    def __init__(self, vehicleNo) -> None:
        self.vehicleNo = vehicleNo
        self.isAvalible = True

class Order:

    def __init__(self, user_name, city, postoffice, items) -> None:
        self.orderId = random.choice(range(10**8,10**9))
        self.user_name = user_name
        self.location = Location(city, postoffice)
        self.items = items
        self.vehicle = None
    
    def calculate_ammount(self):
        total = sum([int(item.price) for item in self.items])
        return total
    
    def assignVehicle(self, vehicle):
        if vehicle.isAvalible:
            self.vehicle = vehicle
            vehicle.isAvalible = False
    
    def __str__(self) -> str:
        string = "Your order number is " + str(self.orderId) + "."
        return string

class LogisticSystem:

    def __init__(self, vehicles) -> None:
        self.orders = []
        self.vehicles = vehicles
    
    def placeOrder(self, order):
        avalible_vehicles = [vehicle for vehicle in self.vehicles if vehicle.isAvalible == True]
        if len(avalible_vehicles) != 0:
            self.orders.append(order)
            order.assignVehicle(random.choice(avalible_vehicles))
        else:
            print("There is no available vehicle to deliver an order.")

    def trackOrder(self, orderId):

        for order in self.orders:
            if order.orderId == orderId:
                string = f"Your order #{orderId} is sent to {order.location.city}. Total price: {order.calculate_ammount()} UAH."
                print(string)
                break
        else:
            print("No such order.")
