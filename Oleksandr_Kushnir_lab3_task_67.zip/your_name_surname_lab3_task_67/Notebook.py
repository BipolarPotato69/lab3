from datetime import datetime

class Notebook:

    def __init__(self) -> None:
        self.notes = []

    def search(self, filter):
        filtered_notes = []
        for note in self.notes:
            if note.match(filter):
                filtered_notes.append(note)
        return filtered_notes
    
    def new_note(self, memo, tags = ""):
        self.notes.append(Note(memo, tags))

    def modify_memo(self, note_id, memo):
        self.notes[note_id].memo = memo

    def modify_tags(self, note_id, tags):
        self.notes[note_id].tags = tags
    
class Note:

    def __init__(self, memo, tags = "") -> None:
        self.creation_date = str(datetime.now())[:16]
        self.tags = tags
        self.memo = memo
    
    def match(self, search_filter):
        return search_filter in self.tags

    def __repr__(self) -> str:
        string = f'[{self.creation_date}]: "{self.memo}"'
        return string
